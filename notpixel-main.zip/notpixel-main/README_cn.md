# NotPixel 多账户100%在线免费Python机器人

此Python NotPixel Bot脚本用于管理NotPixel机器人多账户，支持无限账户，自动像素填充，自动资源领取。如果你能让电脑24/7运行，那么不需要VPS，否则建议购买小型VPS！

**在此注册 NotPixel** - [https://t.me/notpixel/app?startapp=f6032442305](https://t.me/notpixel/app?startapp=f6032442305)

# NotPixel 由 Notcoin 支持

# 获取 Query_id 的步骤 ->

1. 打开Telegram桌面版设置，然后进入 高级 > 实验设置。
2. 开启 `启用网页检查` 选项
3. 完成！登录NOTPIXEL并检查以获取Query ID（右键点击“检查”）。
4. ![image](https://github.com/user-attachments/assets/03ff09a2-227a-4c16-8bca-72617a1c92e6)


# 需要遵循的步骤！

1. 克隆仓库 - `git clone https://github.com/Solana0x/NotPixel`
2. 然后进入目录 - `cd NotPixel`
3. 安装Python
4. 然后执行 `pip install -r requirements.txt`
5. 从Telegram桌面版中通过右键点击你的机器人然后检查获取 `query_id=`
6. 将 `query_id=` 添加到 data.txt 文件中，每一行添加一个新的 `query_id=`
7. 为所有Telegram账户重复此操作
8. 完成后，运行机器人代码 - `python main.py`

# 机器人的功能

1. 自动资源领取
2. 自动填充像素
3. 自动处理所有账户，每小时循环一次
4. 自动获取余额

# 待办事项

1. 自动升级
2. 自动任务
3. 代理支持

# 如需任何帮助，请联系：Discord上的0xphatom https://discord.com/users/979641024215416842

**仅限教育用途：**

此脚本仅用于教育和研究目的。本项目的作者和贡献者对该代码的任何滥用不承担责任。使用此代码的任何行为由用户自行负责。

- **免责申明**: 此代码的作者不对因使用此脚本而发生的任何法律或道德违规行为承担责任。该脚本应仅在受控的、合法的环境中使用，不得用于任何非法活动。滥用此软件可能导致用户受到第三方的法律行动。
  
- **第三方责任**: 作者不对任何组织的行为负责，包括但不限于Blum团队或任何其他可能以任何方式使用或解释此代码的实体。

**版权声明：**

此脚本受 **1976年美国版权法**（Title 17, United States Code）的保护。未经授权复制或分发此脚本或其任何部分，可能会导致严重的民事和刑事处罚，并将根据法律的最大程度起诉。
欲了解更多信息，请参阅法律全文：[美国法典第17条](https://www.copyright.gov/title17/)。
