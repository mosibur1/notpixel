# NotPixel Multi Account 100% Uptime FREE Python Bot

This Python NotPixel Bot script manages Multi Account for NotPixel bot, Unlimited Account Support handling AUTO PIXEL FILL , AUTO RESOURCE CLAIM. If you can run your pc 24/7 then you dont need a Vps else Better buy a small VPS!!

join telegram  https://t.me/savanop121
**Register here NotPixel** - [https://t.me/notpixel/app?startapp=f6032442305](https://t.me/notpixel/app?startapp=f6032442305)

# NotPixel backed by Notcoin

# Get Query_id by ->

1. Go to telegram desktop Settings then Advance > experimental settings.
2. Then Turn on `enable web inspecting`
3. Done ! Login to NOTPIXEL and inspect to get the Query ID (right click to Inspect)
4. ![image](https://github.com/user-attachments/assets/6be1fce1-923b-4f0b-b1e2-71c845e58580)


# Setps to follow !

1. clone the repo - `https://github.com/Savanop121/notpixel.git`
2. Then `cd notPixel`
3. Install Python
4. Then `pip install -r requirements.txt`
6. Get `query_id=` from Telegram desktop by right click on your bot and then inspect
7. Add `query_id=` in data.txt file every line = new `query_id=`
8. Repeat the process for all the Telegram accounts
9. One done Run the Bot code by - `python main.py`
10. For proxy usage use `python proxy.py` add proxy in `proxy.txt file ` formate : `http://username:pass@ip:port`
11. You can buy residentail proxies here `https://dataimpulse.com/?aff=23392` 5-10GB plan will be enough to run BLUM bot + Notpixel bot + future all bots for atleast 10K accounts

# Features of the BOT

1. AUTO RESOURCE CLAIM
2. AUTO FILL THE PIXELS
3. AUTO PROCESS ALL ACCOUNT EVERY HR IN LOOP
4. AUTO FETCHES BALANCES
5. PROXY SUPPORT

# TODO

1. AUTO UPGRADES
2. AUTO TASKS

# FOR ANY KIND OF HELP CONTACT : 0xphatom on Discord https://discord.com/users/979641024215416842

**Educational Purposes Only:**

This script is intended solely for educational and research purposes. The authors and contributors of this project are not responsible for any misuse of this code. Any actions taken using this code are the sole responsibility of the user.

- **Non-Liability**: The authors of this code do not bear any responsibility for legal or ethical violations that occur due to the use of this script. The script should only be used in a controlled, legal environment, and not for any illegal activities. Misuse of this software may result in legal actions taken against the user by third parties.
- **Third-Party Liability**: The author is not responsible for any actions taken by any organization, including but not limited to the NotPixel team, or any other entities that may use or interpret this code in any manner.

**Copyright Notice:**

This script is protected under the provisions of the **U.S. Copyright Act of 1976**, Title 17, United States Code. Unauthorized reproduction or distribution of this script, or any portion of it, may result in severe civil and criminal penalties, and will be prosecuted to the maximum extent possible under the law.
For more information, please consult the full text of the law: [Title 17 of the U.S. Code](https://www.copyright.gov/title17/).


